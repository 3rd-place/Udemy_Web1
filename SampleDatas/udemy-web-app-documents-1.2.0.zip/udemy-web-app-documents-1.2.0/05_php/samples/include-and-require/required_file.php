<?php
function hello()
{
    echo 'Hello PHP!';
}
