<?php

$content = 'Hello! PHP!';

include __DIR__.'/included_file.php';
