<?php

require __DIR__.'/required_file.php';

hello();
