<html>
  <body><?php echo $content; ?></body>
</html>
